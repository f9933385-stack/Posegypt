import 'dart:async';
import 'dart:convert';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';
import 'engine.dart';
import 'security.dart';

class KasherApi {
  final PosEngine engine;
  final AuthService auth;
  KasherApi(this.engine,this.auth);

  Response _json(Object? value,{int status=200}) => Response(status,body:jsonEncode(value),
    headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',
      'x-content-type-options':'nosniff'});
  Principal _p(Request r) {
    final p=auth.authenticate(r.headers['authorization']);
    if(p==null) throw DomainError('Unauthorized',401);
    return p;
  }
  Future<Map<String,dynamic>> _body(Request req) async {
    if(!((req.headers['content-type'] ?? '').startsWith('application/json'))) throw DomainError('Content-Type must be application/json',415);
    final raw=await req.readAsString();
    if(raw.length>131072) throw DomainError('Body too large',413);
    final decoded=jsonDecode(raw);
    if(decoded is! Map<String,dynamic>) throw DomainError('Expected a JSON object');
    return decoded;
  }
  String _branch(Request req) {
    final b=req.url.queryParameters['branch_id'];
    if(b==null || b.isEmpty) throw DomainError('branch_id query required');
    return b;
  }
  Future<Response> _write(Request r,String command) async {
    final p=_p(r), key=r.headers['idempotency-key'];
    if(key==null) throw DomainError('Idempotency-Key header required',400);
    return _json(engine.command(p,command,await _body(r),key),status:201);
  }
  Handler get handler {
    final router=Router();
    router.get('/health', (Request r)=>_json({'status':'ok','service':'kasher-local','version':'0.1.0'}));
    router.post('/api/v1/auth/login', (Request r) async {
      final body=await _body(r);
      final tenant=body['tenant_id'],username=body['username'],password=body['password'];
      if(tenant is! String || username is! String || password is! String) throw DomainError('Missing credentials',400);
      final result=auth.login(tenant,username,password);
      if(result==null) throw DomainError('Invalid credentials',401);
      return _json(result);
    });
    router.post('/api/v1/auth/logout', (Request r) {
      _p(r);
      final token=r.headers['authorization']!.substring(7);
      auth.logout(token);
      return _json({'ok':true});
    });
    router.get('/api/v1/me', (Request r) {
      final p=_p(r);
      return _json({'id':p.id,'tenant_id':p.tenantId,'branch_id':p.branchId,'role':p.role,'username':p.name});
    });
    router.get('/api/v1/users', (Request r)=>_json(engine.listUsers(_p(r))));
    router.get('/api/v1/branches', (Request r)=>_json(engine.listBranches(_p(r))));
    router.get('/api/v1/products', (Request r)=>_json(engine.listProducts(_p(r),
      search:r.url.queryParameters['q'] ?? '')));
    router.get('/api/v1/customers', (Request r)=>_json(engine.listParties(_p(r),customers:true)));
    router.get('/api/v1/suppliers', (Request r)=>_json(engine.listParties(_p(r),customers:false)));
    router.get('/api/v1/stock', (Request r)=>_json(engine.listStock(_p(r),_branch(r))));
    router.get('/api/v1/documents', (Request r)=>_json(engine.listDocuments(_p(r),_branch(r))));
    router.get('/api/v1/documents/<id>', (Request r,String id)=>_json(engine.readDocument(_p(r),id)));
    router.get('/api/v1/dashboard', (Request r)=>_json(engine.dashboard(_p(r),_branch(r))));
    router.get('/api/v1/audit', (Request r)=>_json(engine.audit(_p(r),_branch(r))));
    router.get('/api/v1/shifts', (Request r)=>_json(engine.listShifts(_p(r),_branch(r))));
    router.get('/api/v1/sync/outbox', (Request r)=>_json(engine.outbox(_p(r),_branch(r))));
    final commands={
      'users':'create_user','products':'create_product','customers':'create_customer','suppliers':'create_supplier',
      'branches':'create_branch','purchases':'purchase','sales':'sale','sales/returns':'sale_return',
      'purchases/returns':'purchase_return','customers/receipts':'customer_receipt',
      'suppliers/payments':'supplier_payment','expenses':'expense',
      'inventory/adjustments':'adjust_stock','inventory/preparations':'prepare',
      'shifts/open':'shift_open','shifts/close':'shift_close',
    };
    commands.forEach((path,command){router.post('/api/v1/$path',(Request r)=>_write(r,command));});
    return (Request r) async {
      try {
        return await router.call(r);
      } on DomainError catch(e) {
        return _json({'error':e.message},status:e.status);
      } on FormatException catch(_) {
        return _json({'error':'Invalid input format'},status:400);
      } on ArgumentError catch(_) {
        return _json({'error':'Invalid numeric input'},status:400);
      } on Object catch(e) {
        // Never leak SQL, password hashes or internal paths over LAN.
        // Internal errors should be sent to a sanitized operational logger.
        return _json({'error':'Internal server error'},status:500);
      }
    };
  }
}
